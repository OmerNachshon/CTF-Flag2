import webbrowser


if __name__ == '__main__':
    link = "https://youtu.be/6xckBwPdo1c?t=54"
    webbrowser.open(link)
