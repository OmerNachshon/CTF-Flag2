import os
from random import randint

def list_dirs(dirpath):
    paths= [dirpath]
    for path in os.listdir(dirpath):
        rpath = os.path.join(dirpath, path)
        if os.path.isdir(rpath) and '.' not in rpath.split('/')[1]:
            subdirs = list_dirs(rpath)
            if not subdirs == []:
                paths.extend(subdirs)
    return paths

def solve():
    for dir in list_dirs('./House'): #check all "Rooms" inside "House"
        inner_dirs=os.listdir(dir)  #inner dirs is a list of EVERYTHING INSIDE A ROOM
        for inner_dir in inner_dirs:
            #ignore hidden files and find file that do not contain room as part of name , meanning that's a key
            if 'Room' not in inner_dir and '.' not in inner_dir:
                return dir+'/'+inner_dir

def random_path():
    dirs=list_dirs('./House')
    random_number = randint(0, len(dirs) - 1)
    return dirs[random_number]

def create_rooms():
    if not os.path.exists('House'):
        os.mkdir('House')
    dirs=list_dirs('./House')
    for i in range(10000):
        random_number=randint(0, len(dirs)-1)
        temp_path=dirs[random_number]+f'/Room{i}'
        dirs.append(temp_path)
        os.mkdir(temp_path)


if __name__ == '__main__':
    create_rooms() #used for creating "House" and all of the "Rooms"
    # print the list of sub-directories , and total number of files
    dirs=list_dirs('./House')
    print(len(dirs))
    print(dirs)

    #get random path to store the "key" inside and move key from parent folder
    rnd_path=random_path()
    if os.path.exists("key"):
        os.replace('key',rnd_path+'/key')

    print(solve())